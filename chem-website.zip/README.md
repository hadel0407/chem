# Chemical Process Problem Solving

This is a Jekyll-based website to share chemical process knowledge.  
Built to support:

- Continuous article updates
- Google AdSense integration
- SEO optimization

## Usage

1. Install Jekyll: `gem install jekyll bundler`
2. Run locally: `bundle exec jekyll serve`
3. Deploy to GitHub Pages